<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php if($generated === true): ?>
            <?php $i = 1 ?>
            <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-12 col-md-12 col-lg-6 col-xl-4  game-wrapper">
                    <div class="table-wrapper" style="opacity: 1;transform: rotateX(20deg);width: 274px;">
                        <div class="table-surface">
                            <a href="#">
                                <button class="btn text-dark">Kijken!</button>
                            </a>
                        </div>
                        <div class="table"></div>
                    </div>
                    <div class="table-edge" style="opacity: 1; width: 274px;">
                        <div class="table-leg"></div>
                        <div class="table-leg"></div>
                    </div>
                    <h2>Tafel <?php echo e($i++); ?></h2>
                    <div class="name-tags">
                        <?php if(count($table) == 4): ?>
                            <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span><?php echo e($player->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php elseif(count($table) == 3): ?>
                            <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span><?php echo e($player->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php elseif($generated === false): ?>
            <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-12 col-md-12 col-lg-6 col-xl-4  game-wrapper">
                    <div class="table-wrapper" style="opacity: 1;transform: rotateX(20deg);width: 274px;">
                        <div class="table-surface">
                            <a href="#">
                                <button class="btn text-dark">Kijken!</button>
                            </a>
                        </div>
                        <div class="table"></div>
                    </div>
                    <div class="table-edge" style="opacity: 1; width: 274px;">
                        <div class="table-leg"></div>
                        <div class="table-leg"></div>
                    </div>
                    <h2>Tafel <?php echo e($table->table); ?></h2>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <?php echo e(redirect()->route('round3.index')); ?>

        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if($start_round_2 === false): ?>
            <div>
                <h1>Er worden nog scores verwacht om ronde 2 te starten.</h1>
            </div>
        <?php else: ?>
            <div>
                <form method="post" action="<?php echo e(route('round2.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-primary">Genereer Ronde 2</button>
                </form>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
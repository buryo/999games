<nav class="display-table-cell v-align box position-fixed" id="navigation">
    <div class="logo">
        <a hef="#">
            <img src="<?php echo e(asset('img/logo.png')); ?>">
        </a>
    </div>
    <div class="navi">
        <ul>
            <li class="<?php echo e(Route::currentRouteName() == 'home' ? 'active' : ''); ?>"><a href="<?php echo e(route('home')); ?>"><i class="fa fa-home" aria-hidden="true"></i>Home</a></li>
            <?php if(auth()->guard()->check()): ?>
                <li class="<?php echo e(Route::currentRouteName() == 'attendance' ? 'active' : ''); ?>"><a href="<?php echo e(route('attendance')); ?>"><i class="fa fa-list-alt" aria-hidden="true"></i>Scorebord</a></li>
                <li class="<?php echo e(Route::currentRouteName() == 'attendance' ? 'active' : ''); ?>"><a href="<?php echo e(route('round1.show', 1)); ?>"><i class="fa fa-list-alt" aria-hidden="true"></i>Ronde 1</a></li>
                <li class="<?php echo e(Route::currentRouteName() == 'attendance' ? 'active' : ''); ?>"><a href="<?php echo e(route('round2.show', 2)); ?>"><i class="fa fa-list-alt" aria-hidden="true"></i>Ronde 2</a></li>
                <li class="<?php echo e(Route::currentRouteName() == 'attendance' ? 'active' : ''); ?>"><a href="<?php echo e(route('round3.show', 3)); ?>"><i class="fa fa-list-alt" aria-hidden="true"></i>Ronde 3</a></li>
                <li class="<?php echo e(Route::currentRouteName() == 'attendance' ? 'active' : ''); ?>"><a href="<?php echo e(route('round4.show', 4)); ?>"><i class="fa fa-list-alt" aria-hidden="true"></i>Ronde 4</a></li>
            <?php endif; ?>
            <li class="<?php echo e(Route::currentRouteName() == 'register' ? 'active' : ''); ?>"><a href="<?php echo e(route('register')); ?>"><i class="fa fa-user-plus" aria-hidden="true"></i>Inschrijven</a></li>
        </ul>

        <ul class="nav-login">
            <?php if(auth()->guard()->check()): ?>
                <li>
                    <a href="<?php echo e(route('logout')); ?>"
                       onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <i class="fa fa-sign-out"></i>Loguit
                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </li>
            <?php else: ?>
                <li><a href="<?php echo e(route('login')); ?>"><i class="fa fa-user" aria-hidden="true"></i>Login</a></li>
            <?php endif; ?>
        </ul>
    </div>
</nav>

<?php $__env->startSection("title"); ?>
    Ronde <?php echo e($round); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>

<div class="container">
    <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('game',$game->id)); ?>">Tafel <?php echo e($game->table); ?></a> <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
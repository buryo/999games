<?php $__env->startSection("title", "NK carcasonne inloggen"); ?>

<?php $__env->startSection("content"); ?>
    <div class="container container-login">
        <div class="row wrapper-login justify-content-center">
            <div class="col-md-7 col-sm-12">
                <h2 class="white-text text-center py-4">
                    Inloggen
                </h2>

                <div class="px-lg-5 pt-0">
                    <form class="text-center" method="post" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="md-form">
                            <input type="text" name="email" id="materialUsername" class="form-control"
                                   value="<?php echo e(old('email')); ?>" required>
                            <label for="materialUsername">Email</label>
                            <?php if($errors->has('email')): ?>
                                <p class="text-danger text-left"
                                   role="alert"><?php echo e($errors->first('email')); ?></p>
                            <?php endif; ?>

                        </div>

                        <div class="md-form">
                            <input type="password" name="password" id="materialName"
                                   class="form-control" required>
                            <label for="materialName">Wachtwoord</label>
                            <?php if($errors->has('password')): ?>
                                <p class="text-danger text-left"
                                   role="alert"><?php echo e($errors->first('password')); ?></p>
                            <?php endif; ?>
                        </div>

                        <button class="btn btn-outline-info btn-rounded btn-block my-4 waves-effect z-depth-0"
                                type="submit">Inloggen
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
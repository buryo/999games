<?php $__env->startSection('content'); ?>
    <div class="container">
        <form method="post" action="<?php echo e(route('round1.store')); ?>">
            <?php echo csrf_field(); ?>
            <button class="btn btn-primary">Genereer Ronde 1</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
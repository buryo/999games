<?php $__env->startSection('content'); ?>
    <?php if(auth()->guard()->check()): ?>
        <check-list></check-list>
    <?php else: ?>
        <div class="row justify-content-center">
            <div class="col-6">
                <p>
                    Aan de voet van de Pyreneeën ligt de wereldberoemde Franse vestingstad Carcassonne. De rijke historie van deze unieke plek, van de Romeinen, via de Middeleeuwen tot de Romantiek, diende als inspiratie bij het ontwerpen van een van de populairste bordspellen van deze eeuw:
                </p>

                <h2>Welkom in Carcassonne!</h2>
                <a href="<?php echo e(route('register')); ?>"><button class="btn btn-primary mt-3">Wil je inschrijven?</button></a>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
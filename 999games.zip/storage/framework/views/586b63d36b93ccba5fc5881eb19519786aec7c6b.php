<?php $__env->startSection("title", "Scores invullen"); ?>

<?php $__env->startSection("content"); ?>

<div class="container">
    <form action="<?php echo e(route('game.setScore',$game)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="row my-auto">
        <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="card col" style="width: 10rem; min-height: 10rem;margin-top: 200px">
                <label><?php echo e($player->name); ?></label>
                <input style="color: black !important;" type="number" name="user_<?php echo e($player->id); ?>">
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <button type="submit">Submit</button>

        <?php if($errors->any()): ?>
            <div class="notification is-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?>  </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
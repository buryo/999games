<?php $__env->startSection("title", "NK carcasonne registreren"); ?>

<?php $__env->startSection("content"); ?>
    <div class="container container-login">
        <div class="row wrapper-login justify-content-center">
            <div class="col-md-7 col-sm-12">
                <h2 class="white-text text-center py-4">
                    Registreren
                </h2>

                <div class="px-lg-5 pt-0">
                    <form class="text-center" method="post" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="md-form">
                            <input type="text" name="username" id="materialUsername" class="form-control" value="<?php echo e(old('username')); ?>" required>
                            <label for="materialUsername">Gebruikersnaam</label>
                            <?php if($errors->has('username')): ?>
                                <p class="text-danger text-left" role="alert"><?php echo e($errors->first('username')); ?></p>
                            <?php endif; ?>

                        </div>

                        <div class="md-form">
                            <input type="text" name="name" id="materialName" class="form-control" value="<?php echo e(old('name')); ?>" required>
                            <label for="materialName">Voornaam</label>
                            <?php if($errors->has('name')): ?>
                                <p class="text-danger text-left" role="alert"><?php echo e($errors->first('name')); ?></p>
                            <?php endif; ?>
                        </div>

                        <div class="md-form">
                            <input type="text" name="last_name" id="materialLastName" class="form-control" value="<?php echo e(old('last_name')); ?>" required>
                            <label for="materialLastName">Achternaam</label>
                            <?php if($errors->has('last_name')): ?>
                                <p class="text-danger text-left" role="alert"><?php echo e($errors->first('last_name')); ?></p>
                            <?php endif; ?>
                        </div>

                        <div class="md-form">
                            <input type="email" name="email" id="materialEmail" class="form-control" value="<?php echo e(old('email')); ?>" required>
                            <label for="materialEmail">E-mailadress</label>
                            <?php if($errors->has('email')): ?>
                                <p class="text-danger text-left" role="alert"><?php echo e($errors->first('email')); ?></p>
                            <?php endif; ?>
                        </div>

                        <button class="btn btn-outline-info btn-rounded btn-block my-4 waves-effect z-depth-0"
                                type="submit">Sign in
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
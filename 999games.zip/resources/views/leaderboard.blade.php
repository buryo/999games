@extends("layouts.master")

@section("title", "NK carcasonne")

@section("content")
    <leader-board></leader-board>
@stop
@extends('layouts.master')

@section('content')
    <check-list></check-list>
@endsection
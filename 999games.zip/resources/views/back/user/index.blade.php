@extends('layouts.master')

@section('content')
    <h1>{{ $age }}</h1>
@endsection

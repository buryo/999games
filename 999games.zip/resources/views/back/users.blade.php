@extends('layouts.master')

@section('content')
    content
@endsection
